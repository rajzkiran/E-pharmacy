package com.epharmacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpharmacyApplicationTests {

	@Test
	void contextLoads() {
	}

}
