package com.epharmacy.dto;

public enum CardType {
	
CREDIT_CARD,DEBIT_CARD
}
