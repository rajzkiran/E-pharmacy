package com.epharmacy.dto;

public enum DeliveryStatus {
	AWAITING_CONFIRMATION,
	IN_TRANSIT,
	OUT_FOR_DELIVERY,
	DELIVERED,
	CANCELLED
}
