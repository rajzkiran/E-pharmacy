package com.epharmacy.dto;

public enum OrderStatus {
	PROCESSING,
	CONFIRMED,
	COMPLETED,
	CANCELLED
}
