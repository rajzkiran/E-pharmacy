package com.epharmacy.exception;

public class EPharmacyException extends Exception{
	private static final long serialVersionUID = 1L;

	public EPharmacyException(String message) {
		super(message);
	}
}
